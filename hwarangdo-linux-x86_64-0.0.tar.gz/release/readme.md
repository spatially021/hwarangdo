# HwarangDo 0.0



화랑도(HwarangDo) 언어 컴파일러 0.0 버전입니다.



## Requirements

Linux x86_64

LLVM 21.x 권장

## Usage

실행:



./hwarangdo <source_file>

예:

./hwarangdo examples/main.hgm

Notes

현재 버전은 초기 개발 버전입니다.

일부 기능 및 안정성 검증이 진행 중입니다.

버그 제보 및 피드백을 환영합니다.